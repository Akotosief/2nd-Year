<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="index.css">
        <title>PC BUILD</title>
    </head>
        <body>
            <div class="container">

                    <div class="topper">
                        <a href="index.php"><img src="./images/438293690_756807072962619_7121699218052410435_n.png"  class="logo"; style="width: 50px;" height="50px" margin="0";></a>
                        <ul class="">
                            <li><a href="index.php" class="active">Home</a></li>
                            <li><a href="products.php">Products</a></li>
                            <li><a href="pricelist.php">Price List</a></li>
                        </ul>
                    </div> 
            </div>
            <div class="midder3">    
            <div class="main-container" >
                <input type="radio" class="tab-radio" name="tab" id="tab1" checked>
                <label for="tab1" class="tab-label"> 1</label>   
                <div class="Question-Container">
                    <h2>Photo:</h2>
                    <img src="./aboutphotos/gr1.jpg";>
                </div>
                <!-- Second Page-->
                <input type="radio" class="tab-radio" name="tab" id="tab2">
                <label for="tab2" class="tab-label"> 2</label>     
                <div class="Question-Container">
                    <h2>Photo:</h2>
                    <img src="./aboutphotos/r2.jpg";> 
                </div>

                <input type="radio" class="tab-radio" name="tab" id="tab3">
                <label for="tab3" class="tab-label"> 3</label>     
                <div class="Question-Container">
                    <h2>Photo:</h2>
                    <img src="./aboutphotos/gr3.jpg";>   
                </div><input type="radio" class="tab-radio" name="tab" id="tab4">
                <label for="tab4" class="tab-label"> 4</label>   
                <div class="Question-Container">
                    <h2>Photo:</h2>
                    <img src="./aboutphotos/r4.jpg";>
                </div>

                <input type="radio" class="tab-radio" name="tab" id="tab5">
                <label for="tab5" class="tab-label"> 5</label>     
                <div class="Question-Container">
                    <h2>Photo:</h2>
                    <img src="./aboutphotos/r1.jpg";> 
                </div>

                <input type="radio" class="tab-radio" name="tab" id="tab6">
                <label for="tab6" class="tab-label"> 6</label>     
                <div class="Question-Container">
                    <h2>Photo:</h2>
                    <img src="./aboutphotos/gr2.jpg";>   
                </div>
                <input type="radio" class="tab-radio" name="tab" id="tab7">
                <label for="tab7" class="tab-label"> 7</label>     
                <div class="Question-Container">
                    <h2>Photo:</h2>
                    <img src="./aboutphotos/r3.jpg";> 
                </div>

                <input type="radio" class="tab-radio" name="tab" id="tab8">
                <label for="tab8" class="tab-label"> 8</label>     
                <div class="Question-Container">
                    <h2>Photo:</h2>
                    <img src="./aboutphotos/gr4.jpg";>   
                </div>
                <input type="radio" class="tab-radio" name="tab" id="tab9">
                <label for="tab9" class="tab-label"> 9</label>     
                <div class="Question-Container">
                    <h2>Photo:</h2>
                    <img src="./aboutphotos/r5.jpg";>   
                </div>
            </div>   
            </div>  
        
        </body>
    
</html>
