﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Searchfrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.ComboBox8 = New System.Windows.Forms.ComboBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.ComboBox10 = New System.Windows.Forms.ComboBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.ComboBox11 = New System.Windows.Forms.ComboBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.ComboBox12 = New System.Windows.Forms.ComboBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.ComboBox13 = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.ComboBox14 = New System.Windows.Forms.ComboBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.ComboBox15 = New System.Windows.Forms.ComboBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.ComboBox16 = New System.Windows.Forms.ComboBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.ComboBox17 = New System.Windows.Forms.ComboBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.ComboBox18 = New System.Windows.Forms.ComboBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.ComboBox19 = New System.Windows.Forms.ComboBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.ComboBox20 = New System.Windows.Forms.ComboBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.ComboBox21 = New System.Windows.Forms.ComboBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.ComboBox27 = New System.Windows.Forms.ComboBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.ComboBox23 = New System.Windows.Forms.ComboBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.ComboBox25 = New System.Windows.Forms.ComboBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.ComboBox29 = New System.Windows.Forms.ComboBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.ComboBox31 = New System.Windows.Forms.ComboBox()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.SuspendLayout()
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel1)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel2)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel3)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel4)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel5)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel6)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel7)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel8)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel9)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel10)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel11)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel12)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel13)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel14)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel15)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel16)
        Me.FlowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(731, 2502)
        Me.FlowLayoutPanel1.TabIndex = 41
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.ComboBox3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.ComboBox4)
        Me.Panel1.Controls.Add(Me.TextBox1)
        Me.Panel1.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(3, 2)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(728, 121)
        Me.Panel1.TabIndex = 48
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label1.Location = New System.Drawing.Point(13, 70)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 21)
        Me.Label1.TabIndex = 74
        Me.Label1.Text = "Search"
        '
        'ComboBox3
        '
        Me.ComboBox3.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Items.AddRange(New Object() {"ATHLON", "RYZEN 3", "RYZEN 5", "RYZEN 7", "RYZEN 9", "i3", "i5", "i7", "i9"})
        Me.ComboBox3.Location = New System.Drawing.Point(613, 37)
        Me.ComboBox3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox3.TabIndex = 73
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(13, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(108, 24)
        Me.Label2.TabIndex = 68
        Me.Label2.Text = "Processor"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(611, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 18)
        Me.Label3.TabIndex = 71
        Me.Label3.Text = "Model"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(515, 15)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 18)
        Me.Label4.TabIndex = 70
        Me.Label4.Text = "Chipset"
        '
        'ComboBox4
        '
        Me.ComboBox4.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Items.AddRange(New Object() {"AMD", "Intel"})
        Me.ComboBox4.Location = New System.Drawing.Point(517, 37)
        Me.ComboBox4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox4.TabIndex = 72
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(107, 68)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(599, 29)
        Me.TextBox1.TabIndex = 69
        Me.TextBox1.Tag = ""
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.ComboBox5)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.TextBox2)
        Me.Panel2.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.Location = New System.Drawing.Point(3, 127)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(728, 121)
        Me.Panel2.TabIndex = 49
        Me.Panel2.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label5.Location = New System.Drawing.Point(13, 70)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 21)
        Me.Label5.TabIndex = 74
        Me.Label5.Text = "Search"
        '
        'ComboBox5
        '
        Me.ComboBox5.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Items.AddRange(New Object() {"1st player", "Amd", "Antec", "Arctic", "Asus", "Bequiet", "Coolermaster", "Corsair", "Cougar", "Darkflash", "Deepcool", "Fractal", "Fryst", "Gigabyte", "ld cooling", "Inplay", "Intel", "Jonsbo", "Kingsman", "Lian If", "Msi", "Noctua", "Nyxt", "Ovation", "Phantex", "Xigmatek", "Ygt"})
        Me.ComboBox5.Location = New System.Drawing.Point(613, 37)
        Me.ComboBox5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox5.TabIndex = 73
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(13, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(126, 24)
        Me.Label6.TabIndex = 68
        Me.Label6.Text = "CPU Cooler"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(611, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(54, 18)
        Me.Label7.TabIndex = 71
        Me.Label7.Text = "Brands"
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(107, 68)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(599, 29)
        Me.TextBox2.TabIndex = 69
        Me.TextBox2.Tag = ""
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel3.Controls.Add(Me.Label17)
        Me.Panel3.Controls.Add(Me.ComboBox2)
        Me.Panel3.Controls.Add(Me.Label16)
        Me.Panel3.Controls.Add(Me.Label14)
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.ComboBox1)
        Me.Panel3.Controls.Add(Me.TextBox29)
        Me.Panel3.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel3.Location = New System.Drawing.Point(3, 252)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(728, 121)
        Me.Panel3.TabIndex = 47
        Me.Panel3.Visible = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label17.Location = New System.Drawing.Point(13, 70)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(75, 21)
        Me.Label17.TabIndex = 74
        Me.Label17.Text = "Search"
        '
        'ComboBox2
        '
        Me.ComboBox2.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"A10", "A320", "A520", "A620", "A68", "B250", "B350", "B365", "B450", "B460", "B550", "B550M", "B560", "B570", "B650", "B650M", "B660", "B660M", "B760", "B760", "B760M", "H110", "H310", "H410", "H1510", "H610", "H1810", "INTEL Z790", "X570", "X670", "X760", "Z270", "Z370", "Z490", "Z590", "Z690", "Z790"})
        Me.ComboBox2.Location = New System.Drawing.Point(613, 37)
        Me.ComboBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox2.TabIndex = 73
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(13, 16)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(140, 24)
        Me.Label16.TabIndex = 68
        Me.Label16.Text = "Motherboard"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(611, 16)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(46, 18)
        Me.Label14.TabIndex = 71
        Me.Label14.Text = "Model"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(515, 15)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(54, 18)
        Me.Label15.TabIndex = 70
        Me.Label15.Text = "Brands"
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Asrock", "Asus", "Biostar", "Colorful", "Gigabyte", "Msi", "Nzxt"})
        Me.ComboBox1.Location = New System.Drawing.Point(517, 37)
        Me.ComboBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox1.TabIndex = 72
        '
        'TextBox29
        '
        Me.TextBox29.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox29.Location = New System.Drawing.Point(107, 68)
        Me.TextBox29.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(599, 29)
        Me.TextBox29.TabIndex = 69
        Me.TextBox29.Tag = ""
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel4.Controls.Add(Me.Label9)
        Me.Panel4.Controls.Add(Me.ComboBox7)
        Me.Panel4.Controls.Add(Me.Label10)
        Me.Panel4.Controls.Add(Me.Label11)
        Me.Panel4.Controls.Add(Me.Label12)
        Me.Panel4.Controls.Add(Me.ComboBox8)
        Me.Panel4.Controls.Add(Me.TextBox3)
        Me.Panel4.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel4.Location = New System.Drawing.Point(3, 377)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(728, 121)
        Me.Panel4.TabIndex = 50
        Me.Panel4.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label9.Location = New System.Drawing.Point(13, 70)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(75, 21)
        Me.Label9.TabIndex = 74
        Me.Label9.Text = "Search"
        '
        'ComboBox7
        '
        Me.ComboBox7.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Items.AddRange(New Object() {"4GB", "16GB", "32GB", "64GB", "8GB"})
        Me.ComboBox7.Location = New System.Drawing.Point(613, 37)
        Me.ComboBox7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox7.TabIndex = 73
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(13, 16)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(92, 24)
        Me.Label10.TabIndex = 68
        Me.Label10.Text = "Memory"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(611, 16)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(65, 18)
        Me.Label11.TabIndex = 71
        Me.Label11.Text = "Capacity"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(515, 15)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(54, 18)
        Me.Label12.TabIndex = 70
        Me.Label12.Text = "Brands"
        '
        'ComboBox8
        '
        Me.ComboBox8.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox8.FormattingEnabled = True
        Me.ComboBox8.Items.AddRange(New Object() {"Adata", "Apacer", "Avexir", "Corsair", "Crucial", "Datotek", "Geil", "Geil orion", "Gskill", "Hyperx", "Kingmax", "Kingston", "Leven", "Lexar", "Netac", "Patriot", "Pc cooler", "Pny", "Ramsta", "You sent", "Shikotar", "T-force", "Team elite", "Team group", "Zeppelin"})
        Me.ComboBox8.Location = New System.Drawing.Point(517, 37)
        Me.ComboBox8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox8.Name = "ComboBox8"
        Me.ComboBox8.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox8.TabIndex = 72
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(107, 68)
        Me.TextBox3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(599, 29)
        Me.TextBox3.TabIndex = 69
        Me.TextBox3.Tag = ""
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel5.Controls.Add(Me.Label13)
        Me.Panel5.Controls.Add(Me.ComboBox9)
        Me.Panel5.Controls.Add(Me.Label18)
        Me.Panel5.Controls.Add(Me.Label19)
        Me.Panel5.Controls.Add(Me.Label20)
        Me.Panel5.Controls.Add(Me.ComboBox10)
        Me.Panel5.Controls.Add(Me.TextBox4)
        Me.Panel5.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel5.Location = New System.Drawing.Point(3, 502)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(728, 121)
        Me.Panel5.TabIndex = 51
        Me.Panel5.Visible = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label13.Location = New System.Drawing.Point(13, 70)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(75, 21)
        Me.Label13.TabIndex = 74
        Me.Label13.Text = "Search"
        '
        'ComboBox9
        '
        Me.ComboBox9.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Items.AddRange(New Object() {"GTX-1650", "RTX-3060", "RTX-4060TI", "RTX-4070", "RX-6600"})
        Me.ComboBox9.Location = New System.Drawing.Point(613, 37)
        Me.ComboBox9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox9.TabIndex = 73
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(13, 16)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(157, 24)
        Me.Label18.TabIndex = 68
        Me.Label18.Text = "Graphics Card"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(611, 16)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(46, 18)
        Me.Label19.TabIndex = 71
        Me.Label19.Text = "Model"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(515, 15)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(54, 18)
        Me.Label20.TabIndex = 70
        Me.Label20.Text = "Brands"
        '
        'ComboBox10
        '
        Me.ComboBox10.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox10.FormattingEnabled = True
        Me.ComboBox10.Items.AddRange(New Object() {"Asrock", "Asus", "Galax", "Gigabyte", "Inno3d", "Msi", "Sapphire"})
        Me.ComboBox10.Location = New System.Drawing.Point(517, 37)
        Me.ComboBox10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox10.Name = "ComboBox10"
        Me.ComboBox10.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox10.TabIndex = 72
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(107, 68)
        Me.TextBox4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(599, 29)
        Me.TextBox4.TabIndex = 69
        Me.TextBox4.Tag = ""
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel6.Controls.Add(Me.Label21)
        Me.Panel6.Controls.Add(Me.ComboBox11)
        Me.Panel6.Controls.Add(Me.Label22)
        Me.Panel6.Controls.Add(Me.Label23)
        Me.Panel6.Controls.Add(Me.Label24)
        Me.Panel6.Controls.Add(Me.ComboBox12)
        Me.Panel6.Controls.Add(Me.TextBox5)
        Me.Panel6.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel6.Location = New System.Drawing.Point(3, 627)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(728, 121)
        Me.Panel6.TabIndex = 75
        Me.Panel6.Visible = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label21.Location = New System.Drawing.Point(13, 70)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(75, 21)
        Me.Label21.TabIndex = 74
        Me.Label21.Text = "Search"
        '
        'ComboBox11
        '
        Me.ComboBox11.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Items.AddRange(New Object() {"1TB", "120GB", "1TBGB", "2TB", "240GB", "250GB", "256GB", "2TBGB", "480GB", "500GB", "512GB"})
        Me.ComboBox11.Location = New System.Drawing.Point(613, 37)
        Me.ComboBox11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox11.TabIndex = 73
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(13, 16)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(241, 24)
        Me.Label22.TabIndex = 68
        Me.Label22.Text = "Solid State Drive (M.2)"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(611, 16)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(65, 18)
        Me.Label23.TabIndex = 71
        Me.Label23.Text = "Capacity"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.White
        Me.Label24.Location = New System.Drawing.Point(515, 15)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(54, 18)
        Me.Label24.TabIndex = 70
        Me.Label24.Text = "Brands"
        '
        'ComboBox12
        '
        Me.ComboBox12.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox12.FormattingEnabled = True
        Me.ComboBox12.Items.AddRange(New Object() {"Adata", "Crucial", "Kimtigo", "Kingmax", "Kingstone", "Lexar", "Msi", "Netac", "Pny", "Ramsta", "Samsung", "Team group", "Western digital"})
        Me.ComboBox12.Location = New System.Drawing.Point(517, 37)
        Me.ComboBox12.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox12.Name = "ComboBox12"
        Me.ComboBox12.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox12.TabIndex = 72
        '
        'TextBox5
        '
        Me.TextBox5.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(107, 68)
        Me.TextBox5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(599, 29)
        Me.TextBox5.TabIndex = 69
        Me.TextBox5.Tag = ""
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel7.Controls.Add(Me.Label25)
        Me.Panel7.Controls.Add(Me.ComboBox13)
        Me.Panel7.Controls.Add(Me.Label26)
        Me.Panel7.Controls.Add(Me.Label27)
        Me.Panel7.Controls.Add(Me.Label28)
        Me.Panel7.Controls.Add(Me.ComboBox14)
        Me.Panel7.Controls.Add(Me.TextBox6)
        Me.Panel7.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel7.Location = New System.Drawing.Point(3, 752)
        Me.Panel7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(728, 121)
        Me.Panel7.TabIndex = 76
        Me.Panel7.Visible = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label25.Location = New System.Drawing.Point(13, 70)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(75, 21)
        Me.Label25.TabIndex = 74
        Me.Label25.Text = "Search"
        '
        'ComboBox13
        '
        Me.ComboBox13.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox13.FormattingEnabled = True
        Me.ComboBox13.Items.AddRange(New Object() {"1TB", "120GB", "1TBGB", "2TB", "240GB", "250GB", "256GB", "2TBGB", "480GB", "500GB", "512GB"})
        Me.ComboBox13.Location = New System.Drawing.Point(613, 37)
        Me.ComboBox13.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox13.Name = "ComboBox13"
        Me.ComboBox13.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox13.TabIndex = 73
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.White
        Me.Label26.Location = New System.Drawing.Point(13, 16)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(258, 24)
        Me.Label26.TabIndex = 68
        Me.Label26.Text = "Solid State Drive (SATA)"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.White
        Me.Label27.Location = New System.Drawing.Point(611, 16)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(65, 18)
        Me.Label27.TabIndex = 71
        Me.Label27.Text = "Capacity"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.White
        Me.Label28.Location = New System.Drawing.Point(515, 15)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(54, 18)
        Me.Label28.TabIndex = 70
        Me.Label28.Text = "Brands"
        '
        'ComboBox14
        '
        Me.ComboBox14.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox14.FormattingEnabled = True
        Me.ComboBox14.Items.AddRange(New Object() {"Adata", "Apacer", "Asus", "Colorful", "Crucial", "Gigabyte", "Kingmax", "Kingston", "Kiew", "Lexar", "Netac", "Pny", "Ramsta", "Samsung", "Sandisk", "Segpate", "Team elite", "Team group", "Western digital"})
        Me.ComboBox14.Location = New System.Drawing.Point(517, 37)
        Me.ComboBox14.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox14.Name = "ComboBox14"
        Me.ComboBox14.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox14.TabIndex = 72
        '
        'TextBox6
        '
        Me.TextBox6.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(107, 68)
        Me.TextBox6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(599, 29)
        Me.TextBox6.TabIndex = 69
        Me.TextBox6.Tag = ""
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel8.Controls.Add(Me.Label29)
        Me.Panel8.Controls.Add(Me.ComboBox15)
        Me.Panel8.Controls.Add(Me.Label30)
        Me.Panel8.Controls.Add(Me.Label31)
        Me.Panel8.Controls.Add(Me.Label32)
        Me.Panel8.Controls.Add(Me.ComboBox16)
        Me.Panel8.Controls.Add(Me.TextBox7)
        Me.Panel8.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel8.Location = New System.Drawing.Point(3, 877)
        Me.Panel8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(728, 121)
        Me.Panel8.TabIndex = 77
        Me.Panel8.Visible = False
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label29.Location = New System.Drawing.Point(13, 70)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(75, 21)
        Me.Label29.TabIndex = 74
        Me.Label29.Text = "Search"
        '
        'ComboBox15
        '
        Me.ComboBox15.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox15.FormattingEnabled = True
        Me.ComboBox15.Items.AddRange(New Object() {"1TB", "2TB", "10TB", "4TB", "3TB", "6TB", "8TB"})
        Me.ComboBox15.Location = New System.Drawing.Point(613, 37)
        Me.ComboBox15.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox15.Name = "ComboBox15"
        Me.ComboBox15.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox15.TabIndex = 73
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.White
        Me.Label30.Location = New System.Drawing.Point(13, 16)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(174, 24)
        Me.Label30.TabIndex = 68
        Me.Label30.Text = "Hard Disk Drive"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.White
        Me.Label31.Location = New System.Drawing.Point(611, 16)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(65, 18)
        Me.Label31.TabIndex = 71
        Me.Label31.Text = "Capacity"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.White
        Me.Label32.Location = New System.Drawing.Point(515, 15)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(54, 18)
        Me.Label32.TabIndex = 70
        Me.Label32.Text = "Brands"
        '
        'ComboBox16
        '
        Me.ComboBox16.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox16.FormattingEnabled = True
        Me.ComboBox16.Items.AddRange(New Object() {"Adata", "Seagate", "Toshiba", "Western digital"})
        Me.ComboBox16.Location = New System.Drawing.Point(517, 37)
        Me.ComboBox16.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox16.Name = "ComboBox16"
        Me.ComboBox16.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox16.TabIndex = 72
        '
        'TextBox7
        '
        Me.TextBox7.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.Location = New System.Drawing.Point(107, 68)
        Me.TextBox7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(599, 29)
        Me.TextBox7.TabIndex = 69
        Me.TextBox7.Tag = ""
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel9.Controls.Add(Me.Label33)
        Me.Panel9.Controls.Add(Me.ComboBox17)
        Me.Panel9.Controls.Add(Me.Label34)
        Me.Panel9.Controls.Add(Me.Label35)
        Me.Panel9.Controls.Add(Me.Label36)
        Me.Panel9.Controls.Add(Me.ComboBox18)
        Me.Panel9.Controls.Add(Me.TextBox8)
        Me.Panel9.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel9.Location = New System.Drawing.Point(3, 1002)
        Me.Panel9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(728, 121)
        Me.Panel9.TabIndex = 78
        Me.Panel9.Visible = False
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label33.Location = New System.Drawing.Point(13, 70)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(75, 21)
        Me.Label33.TabIndex = 74
        Me.Label33.Text = "Search"
        '
        'ComboBox17
        '
        Me.ComboBox17.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox17.FormattingEnabled = True
        Me.ComboBox17.Items.AddRange(New Object() {"100W", "1300W", "400W", "450W", "500W", "520W", "530W", "550W", "600W", "620W", "650W", "700W", "750W", "850W", "1000W"})
        Me.ComboBox17.Location = New System.Drawing.Point(617, 37)
        Me.ComboBox17.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox17.Name = "ComboBox17"
        Me.ComboBox17.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox17.TabIndex = 73
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.White
        Me.Label34.Location = New System.Drawing.Point(13, 16)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(147, 24)
        Me.Label34.TabIndex = 68
        Me.Label34.Text = "Power Supply"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.White
        Me.Label35.Location = New System.Drawing.Point(613, 16)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(45, 18)
        Me.Label35.TabIndex = 71
        Me.Label35.Text = "Watts"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.White
        Me.Label36.Location = New System.Drawing.Point(517, 15)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(54, 18)
        Me.Label36.TabIndex = 70
        Me.Label36.Text = "Brands"
        '
        'ComboBox18
        '
        Me.ComboBox18.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox18.FormattingEnabled = True
        Me.ComboBox18.Items.AddRange(New Object() {"Acer", "Aerocool", "Antec", "Asus", "Atom", "Coolermaster", "Corsair", "Cougar", "Darkflash", "Deepcool", "Evga", "Fsp", "Gigabyte", "Inplay", "Intelligent", "Keytech", "Montech", "Msi", "Nzxt", "Raidmax", "Rakk", "Ramsta", "Seasonic", "Silverstone", "Superflower", "Thermaltake", "Trigon", "Xpg", "Xtyle"})
        Me.ComboBox18.Location = New System.Drawing.Point(521, 37)
        Me.ComboBox18.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox18.Name = "ComboBox18"
        Me.ComboBox18.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox18.TabIndex = 72
        '
        'TextBox8
        '
        Me.TextBox8.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.Location = New System.Drawing.Point(107, 68)
        Me.TextBox8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(599, 29)
        Me.TextBox8.TabIndex = 69
        Me.TextBox8.Tag = ""
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel10.Controls.Add(Me.Label37)
        Me.Panel10.Controls.Add(Me.ComboBox19)
        Me.Panel10.Controls.Add(Me.Label38)
        Me.Panel10.Controls.Add(Me.Label39)
        Me.Panel10.Controls.Add(Me.Label40)
        Me.Panel10.Controls.Add(Me.ComboBox20)
        Me.Panel10.Controls.Add(Me.TextBox9)
        Me.Panel10.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel10.Location = New System.Drawing.Point(3, 1127)
        Me.Panel10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(728, 121)
        Me.Panel10.TabIndex = 79
        Me.Panel10.Visible = False
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label37.Location = New System.Drawing.Point(13, 70)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(75, 21)
        Me.Label37.TabIndex = 74
        Me.Label37.Text = "Search"
        '
        'ComboBox19
        '
        Me.ComboBox19.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox19.FormattingEnabled = True
        Me.ComboBox19.Items.AddRange(New Object() {"ATX", "EATX", "ITX", "MICRO-ATX", "MINI-ITX", "MATX", "MITX", "E-ATX", "M-ATX"})
        Me.ComboBox19.Location = New System.Drawing.Point(617, 37)
        Me.ComboBox19.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox19.Name = "ComboBox19"
        Me.ComboBox19.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox19.TabIndex = 73
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.White
        Me.Label38.Location = New System.Drawing.Point(13, 16)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(58, 24)
        Me.Label38.TabIndex = 68
        Me.Label38.Text = "Case"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.White
        Me.Label39.Location = New System.Drawing.Point(613, 16)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(87, 18)
        Me.Label39.TabIndex = 71
        Me.Label39.Text = "Form Factor"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.White
        Me.Label40.Location = New System.Drawing.Point(517, 15)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(54, 18)
        Me.Label40.TabIndex = 70
        Me.Label40.Text = "Brands"
        '
        'ComboBox20
        '
        Me.ComboBox20.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox20.FormattingEnabled = True
        Me.ComboBox20.Items.AddRange(New Object() {"Aerocool", "Antec", "Asus", "Bequiet", "Coolermaster", "Corsair", "Darkflash", "Deepcool", "Fantech", "Fractal", "Fsp", "Galax", "Gamdias", "Hyte", "Inplay", "Inwin", "Jonsbo", "Keytech", "Lian li", "Montech", "Msi", "Neutron", "Nyxt", "Orion", "Ovation", "Phanteks", "Power logic", "Rakk", "Silvestone", "Soul battleship", "Thermaltake", "Trigon", "Wj coolman", "Xstyle", "Ygt"})
        Me.ComboBox20.Location = New System.Drawing.Point(521, 37)
        Me.ComboBox20.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox20.Name = "ComboBox20"
        Me.ComboBox20.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox20.TabIndex = 72
        '
        'TextBox9
        '
        Me.TextBox9.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.Location = New System.Drawing.Point(107, 68)
        Me.TextBox9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(599, 29)
        Me.TextBox9.TabIndex = 69
        Me.TextBox9.Tag = ""
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel11.Controls.Add(Me.Label41)
        Me.Panel11.Controls.Add(Me.ComboBox21)
        Me.Panel11.Controls.Add(Me.Label42)
        Me.Panel11.Controls.Add(Me.Label43)
        Me.Panel11.Controls.Add(Me.TextBox10)
        Me.Panel11.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel11.Location = New System.Drawing.Point(3, 1252)
        Me.Panel11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(728, 121)
        Me.Panel11.TabIndex = 80
        Me.Panel11.Visible = False
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label41.Location = New System.Drawing.Point(13, 70)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(75, 21)
        Me.Label41.TabIndex = 74
        Me.Label41.Text = "Search"
        '
        'ComboBox21
        '
        Me.ComboBox21.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox21.FormattingEnabled = True
        Me.ComboBox21.Items.AddRange(New Object() {"Acer", "Alienware", "Aoc", "Asrock", "Asus", "Benq", "Coolermaster", "Dell", "Fonudar", "Galax", "Gamdias", "Gigabyte", "Hikvision", "Huawei", "Inplay", "Lenovo", "Lg", "Migen", "Msi", "Nvision", "Omnia", "Orion", "Philips", "Samsung", "Specterpo", "Viewplus", "Viewpoint", "Viewsonic", "Xiaomi", "Zowie"})
        Me.ComboBox21.Location = New System.Drawing.Point(617, 37)
        Me.ComboBox21.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox21.Name = "ComboBox21"
        Me.ComboBox21.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox21.TabIndex = 73
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.White
        Me.Label42.Location = New System.Drawing.Point(13, 16)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(86, 24)
        Me.Label42.TabIndex = 68
        Me.Label42.Text = "Display"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.White
        Me.Label43.Location = New System.Drawing.Point(613, 16)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(54, 18)
        Me.Label43.TabIndex = 71
        Me.Label43.Text = "Brands"
        '
        'TextBox10
        '
        Me.TextBox10.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox10.Location = New System.Drawing.Point(107, 68)
        Me.TextBox10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(599, 29)
        Me.TextBox10.TabIndex = 69
        Me.TextBox10.Tag = ""
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel12.Controls.Add(Me.Label53)
        Me.Panel12.Controls.Add(Me.ComboBox27)
        Me.Panel12.Controls.Add(Me.Label54)
        Me.Panel12.Controls.Add(Me.Label55)
        Me.Panel12.Controls.Add(Me.TextBox13)
        Me.Panel12.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel12.Location = New System.Drawing.Point(3, 1377)
        Me.Panel12.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(728, 121)
        Me.Panel12.TabIndex = 83
        Me.Panel12.Visible = False
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label53.Location = New System.Drawing.Point(13, 70)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(75, 21)
        Me.Label53.TabIndex = 74
        Me.Label53.Text = "Search"
        '
        'ComboBox27
        '
        Me.ComboBox27.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox27.FormattingEnabled = True
        Me.ComboBox27.Items.AddRange(New Object() {"A4tech", "Alienware", "Anubis", "Asus", "Bloody", "Cidoo", "Coolermaster", "Corsair", "Darkflash", "Deepcool", "Digi one", "Ducky", "Fantech", "Galax", "Gamdias", "Glorious", "Hp", "Hyperx", "Inplay", "Keychron", "Leopoid", "Logitech", "Motospeed", "Mountain", "Nexion", "Onikuma", "Rakk", "Razer", "Redragon", "Royal", "Royal kludge", "Skylong", "Varmilo", "Vertux"})
        Me.ComboBox27.Location = New System.Drawing.Point(617, 37)
        Me.ComboBox27.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox27.Name = "ComboBox27"
        Me.ComboBox27.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox27.TabIndex = 73
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.ForeColor = System.Drawing.Color.White
        Me.Label54.Location = New System.Drawing.Point(13, 16)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(106, 24)
        Me.Label54.TabIndex = 68
        Me.Label54.Text = "Keyboard"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.ForeColor = System.Drawing.Color.White
        Me.Label55.Location = New System.Drawing.Point(613, 16)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(54, 18)
        Me.Label55.TabIndex = 71
        Me.Label55.Text = "Brands"
        '
        'TextBox13
        '
        Me.TextBox13.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox13.Location = New System.Drawing.Point(107, 68)
        Me.TextBox13.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(599, 29)
        Me.TextBox13.TabIndex = 69
        Me.TextBox13.Tag = ""
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel13.Controls.Add(Me.Label45)
        Me.Panel13.Controls.Add(Me.ComboBox23)
        Me.Panel13.Controls.Add(Me.Label46)
        Me.Panel13.Controls.Add(Me.Label47)
        Me.Panel13.Controls.Add(Me.TextBox11)
        Me.Panel13.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel13.Location = New System.Drawing.Point(3, 1502)
        Me.Panel13.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(728, 121)
        Me.Panel13.TabIndex = 81
        Me.Panel13.Visible = False
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label45.Location = New System.Drawing.Point(13, 70)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(75, 21)
        Me.Label45.TabIndex = 74
        Me.Label45.Text = "Search"
        '
        'ComboBox23
        '
        Me.ComboBox23.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox23.FormattingEnabled = True
        Me.ComboBox23.Items.AddRange(New Object() {"A4tech", "Alienware", "Aoc", "Asus", "Benq", "Bloody", "Coolermaster", "Corsair", "Darkflash", "Fantech", "Frozt", "Galax", "Gamdias", "Glorious", "HK", "Hyperx", "Keychron", "Keytech", "You sent", "Logitech", "Madcatz", "Mionix", "Motospeed", "Msi", "Nexion", "Onikuma", "Prolink", "Rakk", "Razer", "Redragon", "Steelseries"})
        Me.ComboBox23.Location = New System.Drawing.Point(617, 37)
        Me.ComboBox23.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox23.Name = "ComboBox23"
        Me.ComboBox23.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox23.TabIndex = 73
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ForeColor = System.Drawing.Color.White
        Me.Label46.Location = New System.Drawing.Point(13, 16)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(74, 24)
        Me.Label46.TabIndex = 68
        Me.Label46.Text = "Mouse"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.White
        Me.Label47.Location = New System.Drawing.Point(613, 16)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(54, 18)
        Me.Label47.TabIndex = 71
        Me.Label47.Text = "Brands"
        '
        'TextBox11
        '
        Me.TextBox11.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox11.Location = New System.Drawing.Point(107, 68)
        Me.TextBox11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(599, 29)
        Me.TextBox11.TabIndex = 69
        Me.TextBox11.Tag = ""
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel14.Controls.Add(Me.Label49)
        Me.Panel14.Controls.Add(Me.ComboBox25)
        Me.Panel14.Controls.Add(Me.Label50)
        Me.Panel14.Controls.Add(Me.Label51)
        Me.Panel14.Controls.Add(Me.TextBox12)
        Me.Panel14.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel14.Location = New System.Drawing.Point(3, 1627)
        Me.Panel14.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(728, 121)
        Me.Panel14.TabIndex = 82
        Me.Panel14.Visible = False
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label49.Location = New System.Drawing.Point(13, 70)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(75, 21)
        Me.Label49.TabIndex = 74
        Me.Label49.Text = "Search"
        '
        'ComboBox25
        '
        Me.ComboBox25.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox25.FormattingEnabled = True
        Me.ComboBox25.Items.AddRange(New Object() {"A4tech", "Adata", "Asus", "Bloody", "Cliptec", "Corsair", "Edifier", "Eksa", "Fantech", "Galax", "Hp", "Hyperx", "Inplay", "Jabra", "Jbl", "Livey", "Logitech", "Motospeed", "Nexion", "Galax", "Hp", "HyperX", "Inplay", "Jabra", "Jbi", "Livey", "Logitech", "Motospeed", "Nexion", "Onikuma", "Ovation", "P47", "Plantronics", "Rakk", "Razer", "Redragon", "Sony", "Steelseries", "Vertux"})
        Me.ComboBox25.Location = New System.Drawing.Point(617, 37)
        Me.ComboBox25.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox25.Name = "ComboBox25"
        Me.ComboBox25.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox25.TabIndex = 73
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.White
        Me.Label50.Location = New System.Drawing.Point(13, 16)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(91, 24)
        Me.Label50.TabIndex = 68
        Me.Label50.Text = "Headset"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.White
        Me.Label51.Location = New System.Drawing.Point(613, 16)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(54, 18)
        Me.Label51.TabIndex = 71
        Me.Label51.Text = "Brands"
        '
        'TextBox12
        '
        Me.TextBox12.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(107, 68)
        Me.TextBox12.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(599, 29)
        Me.TextBox12.TabIndex = 69
        Me.TextBox12.Tag = ""
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel15.Controls.Add(Me.Label57)
        Me.Panel15.Controls.Add(Me.ComboBox29)
        Me.Panel15.Controls.Add(Me.Label58)
        Me.Panel15.Controls.Add(Me.Label59)
        Me.Panel15.Controls.Add(Me.TextBox14)
        Me.Panel15.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel15.Location = New System.Drawing.Point(3, 1752)
        Me.Panel15.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(728, 121)
        Me.Panel15.TabIndex = 84
        Me.Panel15.Visible = False
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label57.Location = New System.Drawing.Point(13, 70)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(75, 21)
        Me.Label57.TabIndex = 74
        Me.Label57.Text = "Search"
        '
        'ComboBox29
        '
        Me.ComboBox29.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox29.FormattingEnabled = True
        Me.ComboBox29.Items.AddRange(New Object() {"A4tech", "Asus", "Cabstone", "Creative", "Echo dot", "Edifier", "F&d", "Fantech", "Jbl", "Logitech", "Promate", "Vertuz", "Zeus"})
        Me.ComboBox29.Location = New System.Drawing.Point(617, 37)
        Me.ComboBox29.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox29.Name = "ComboBox29"
        Me.ComboBox29.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox29.TabIndex = 73
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.ForeColor = System.Drawing.Color.White
        Me.Label58.Location = New System.Drawing.Point(13, 16)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(91, 24)
        Me.Label58.TabIndex = 68
        Me.Label58.Text = "Speaker"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.ForeColor = System.Drawing.Color.White
        Me.Label59.Location = New System.Drawing.Point(613, 16)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(54, 18)
        Me.Label59.TabIndex = 71
        Me.Label59.Text = "Brands"
        '
        'TextBox14
        '
        Me.TextBox14.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox14.Location = New System.Drawing.Point(107, 68)
        Me.TextBox14.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(599, 29)
        Me.TextBox14.TabIndex = 69
        Me.TextBox14.Tag = ""
        '
        'Panel16
        '
        Me.Panel16.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel16.Controls.Add(Me.Label61)
        Me.Panel16.Controls.Add(Me.ComboBox31)
        Me.Panel16.Controls.Add(Me.Label62)
        Me.Panel16.Controls.Add(Me.Label63)
        Me.Panel16.Controls.Add(Me.TextBox15)
        Me.Panel16.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel16.Location = New System.Drawing.Point(3, 1877)
        Me.Panel16.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(728, 121)
        Me.Panel16.TabIndex = 85
        Me.Panel16.Visible = False
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label61.Location = New System.Drawing.Point(13, 70)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(75, 21)
        Me.Label61.TabIndex = 74
        Me.Label61.Text = "Search"
        '
        'ComboBox31
        '
        Me.ComboBox31.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox31.FormattingEnabled = True
        Me.ComboBox31.Items.AddRange(New Object() {"A4tech", "Cliptec", "Dji", "Dlink", "Fantech", "Gamdias", "Inplay", "Logitech", "Rapoo", "Razer", "Redragon", "Steamplify"})
        Me.ComboBox31.Location = New System.Drawing.Point(617, 37)
        Me.ComboBox31.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ComboBox31.Name = "ComboBox31"
        Me.ComboBox31.Size = New System.Drawing.Size(87, 26)
        Me.ComboBox31.TabIndex = 73
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.ForeColor = System.Drawing.Color.White
        Me.Label62.Location = New System.Drawing.Point(13, 16)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(216, 24)
        Me.Label62.TabIndex = 68
        Me.Label62.Text = "Web Digital Camera"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Bookman Old Style", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.ForeColor = System.Drawing.Color.White
        Me.Label63.Location = New System.Drawing.Point(613, 16)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(54, 18)
        Me.Label63.TabIndex = 71
        Me.Label63.Text = "Brands"
        '
        'TextBox15
        '
        Me.TextBox15.Font = New System.Drawing.Font("Bookman Old Style", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox15.Location = New System.Drawing.Point(107, 68)
        Me.TextBox15.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(599, 29)
        Me.TextBox15.TabIndex = 69
        Me.TextBox15.Tag = ""
        '
        'Searchfrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.ClientSize = New System.Drawing.Size(1139, 884)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Searchfrm"
        Me.Text = "Searchfrm"
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label17 As Label
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents TextBox29 As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents ComboBox5 As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents ComboBox7 As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents ComboBox8 As ComboBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents ComboBox9 As ComboBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents ComboBox10 As ComboBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label21 As Label
    Friend WithEvents ComboBox11 As ComboBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents ComboBox12 As ComboBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label25 As Label
    Friend WithEvents ComboBox13 As ComboBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents ComboBox14 As ComboBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Label29 As Label
    Friend WithEvents ComboBox15 As ComboBox
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents ComboBox16 As ComboBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Label33 As Label
    Friend WithEvents ComboBox17 As ComboBox
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents ComboBox18 As ComboBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Label37 As Label
    Friend WithEvents ComboBox19 As ComboBox
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents ComboBox20 As ComboBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Label41 As Label
    Friend WithEvents ComboBox21 As ComboBox
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Label45 As Label
    Friend WithEvents ComboBox23 As ComboBox
    Friend WithEvents Label46 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Label49 As Label
    Friend WithEvents ComboBox25 As ComboBox
    Friend WithEvents Label50 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Label53 As Label
    Friend WithEvents ComboBox27 As ComboBox
    Friend WithEvents Label54 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Label57 As Label
    Friend WithEvents ComboBox29 As ComboBox
    Friend WithEvents Label58 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Label61 As Label
    Friend WithEvents ComboBox31 As ComboBox
    Friend WithEvents Label62 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents TextBox15 As TextBox
End Class
