// Singleton Design Pattern
const Singleton = (function() {
  let instance;

  function createInstance() {
    const object = new Object("I am the instance");
    return object;
  }

  return {
    getInstance: function() {
      if (!instance) {
        instance = createInstance();
      }
      return instance;
    },
  };
})();

// Invertebrates Data
const invertebrates = [
  { name: "Spider", class: "Arachnida", habitat: "Terrestrial" },
  { name: "Butterfly", class: "Insecta", habitat: "Terrestrial" },
  { name: "Octopus", class: "Cephalopoda", habitat: "Marine" },
];

// Update Image
const imageElement = document.getElementById("invertebrates.jpeg");
imageElement.src = "invertebrates.jpeg";

// Update Table
const tableElement = document.getElementById("invertebrates-table");

// Add table header
const tableHeader = document.createElement("tr");
tableHeader.innerHTML =
  "<th>Name</th><th>Class</th><th>Habitat</th>";
tableElement.appendChild(tableHeader);

// Add table rows
invertebrates.forEach((invertebrate) => {
  const row = document.createElement("tr");
  row.innerHTML = `<td>${invertebrate.name}</td><td>${invertebrate.class}</td><td>${invertebrate.habitat}</td>`;
  tableElement.appendChild(row);
});

// Test Singleton
const instance1 = Singleton.getInstance();
const instance2 = Singleton.getInstance();

console.log("Same instance? " + (instance1 === instance2)); // Output: Same instance? true