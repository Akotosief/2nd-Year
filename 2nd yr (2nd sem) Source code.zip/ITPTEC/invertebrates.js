var Invertebrates = (function() {
  // Private variables and methods
  var instance; // Stores the Singleton instance
  var Ivertebrates = []; // Private variable for storing vertebrates

  function createInstance() {
    // Private constructor function to create a new instance of the Singleton
    return {
      addInvertebrate: function(vertebrate) {
        Invertebrates.push(vertebrate);
      },
      getInvertebrates: function() {
        return vertebrates;
      }
      // Add any other methods or properties you need
    };
  }

  return {
    getInstance: function() {
      // Public method to get the Singleton instance
      if (!instance) {
        instance = createInstance();
      }
      return instance;
    }
  };
})();

// Usage
var singleton = Vertebrates.getInstance();

singleton.addVertebrate("Dog");
singleton.addVertebrate("Cat");
singleton.addVertebrate("Bird");

console.log(singleton.getVertebrates()); // Output: ["Dog", "Cat", "Bird"]  condition ? true : false  