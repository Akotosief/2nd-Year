let ask = prompt("maasim kaba?")
if(ask == "oo"||ask== "hindi"||ask =="OO"){
  console.log("HAHAHAH gago")
}
else {
  console.log("nakikiamoy ka lang!!")
}
